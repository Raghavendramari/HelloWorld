﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MonitoringUI.ViewModel;
using System.Windows.Input;
using MonitoringUI.NurseMonitoringService;
using MonitoringUI.Model;
using System.ComponentModel;
using MonitoringUI.VitalsDataService;
using System.Threading;
using System.ServiceModel;
using System.Collections.ObjectModel;

namespace MonitoringUI.ViewModel
{

    public class NurseMonitoringViewModel : INotifyPropertyChanged
    {


        public NurseMonitoringViewModel()
        {
            var nurse1Client = new NurseMonitoringServiceClient(new InstanceContext(new NurseMonitoringCallback()));
            nurse1Client.SubscribeToVitals("111", "PIC-2F-2A-1");
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(name));
        }
        public void RaisePropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }





        public  ObservableCollection<NurseMonitoringService.Vitals> PatientVitals
        {
            get
            {
                NurseMonitoringCallback nurseMonitor = new NurseMonitoringCallback();
                return nurseMonitor.patientWarning;
            }
            set
            {
                NurseMonitoringCallback nurseMonitor = new NurseMonitoringCallback();
                nurseMonitor.patientWarning = value;
                OnPropertyChanged("PatientVitals");
                RaisePropertyChanged("PatientVitals");
            }            
        }

        public string warningPatID
        {
            get
            {
                NurseMonitoringCallback nurseMonitor = new NurseMonitoringCallback();
                return nurseMonitor.WarningPatID;                
            }
            set
            {
                NurseMonitoringCallback nurseMonitor = new NurseMonitoringCallback();
                nurseMonitor.WarningPatID = value;
                OnPropertyChanged("warningPatID");
                RaisePropertyChanged("warningPatID");
            }
        }


        
    }

    public class NurseMonitoringCallback : INurseMonitoringServiceCallback
    {
        public string WarningPatID { get; set; }

        public ObservableCollection<MonitoringUI.NurseMonitoringService.Vitals> patientWarning { get; set; }

        public void ReceiveAlerts(PatientAlert alert)
        {
            PatientAlert patientAlert = new PatientAlert();
            string _patientid = patientAlert.PatientId;
            Dictionary<string, List<DeviceAlert>> patientcriticalAlerts = new Dictionary<string, List<DeviceAlert>>();
            List<DeviceAlert> deviceAlertslist = new List<DeviceAlert>();
            foreach (var alerts in patientAlert.CriticalAlerts)
            {
                deviceAlertslist.Add(alerts);
            }
            patientcriticalAlerts.Add(_patientid, deviceAlertslist);
            Dictionary<string, List<DeviceAlert>> patientwarningAlerts = new Dictionary<string, List<DeviceAlert>>();
            List<DeviceAlert> deviceAlertslist1 = new List<DeviceAlert>();
            foreach (var alerts in patientAlert.WarningAlerts)
            {
                deviceAlertslist1.Add(alerts);
            }
            patientwarningAlerts.Add(_patientid, deviceAlertslist1);

        }

        public void ReceiveVitals(MonitoringUI.NurseMonitoringService.PatientVitals vitals)
        {

            WarningPatID = vitals.PatientId;
            ObservableCollection<MonitoringUI.NurseMonitoringService.Vitals> vital = new ObservableCollection<MonitoringUI.NurseMonitoringService.Vitals>();
            foreach (MonitoringUI.NurseMonitoringService.Vitals vit in vitals.Vitals)
            {
                vital.Add(vit);

            }

            patientWarning = vital;
        }
    }

}



//class NurseMonitoringCallback : INurseMonitoringServiceCallback
//{
//    public string WarningPatID { get; set; }

//    public ObservableCollection<MonitoringUI.NurseMonitoringService.Vitals> patientWarning { get; set; }

//    public void ReceiveAlerts(PatientAlert alert)
//    {
//        PatientAlert patientAlert = new PatientAlert();
//        string _patientid = patientAlert.PatientId;
//        Dictionary<string, List<DeviceAlert>> patientcriticalAlerts = new Dictionary<string, List<DeviceAlert>>();
//        List<DeviceAlert> deviceAlertslist = new List<DeviceAlert>();
//        foreach (var alerts in patientAlert.CriticalAlerts)
//        {
//            deviceAlertslist.Add(alerts);
//        }
//        patientcriticalAlerts.Add(_patientid, deviceAlertslist);
//        Dictionary<string, List<DeviceAlert>> patientwarningAlerts = new Dictionary<string, List<DeviceAlert>>();
//        List<DeviceAlert> deviceAlertslist1 = new List<DeviceAlert>();
//        foreach (var alerts in patientAlert.WarningAlerts)
//        {
//            deviceAlertslist1.Add(alerts);
//        }
//        patientwarningAlerts.Add(_patientid, deviceAlertslist1);

//    }

//    public void ReceiveVitals(MonitoringUI.NurseMonitoringService.PatientVitals vitals)
//    {

//        WarningPatID = vitals.PatientId;
//        ObservableCollection<MonitoringUI.NurseMonitoringService.Vitals> vital = new ObservableCollection<MonitoringUI.NurseMonitoringService.Vitals>();
//        foreach (MonitoringUI.NurseMonitoringService.Vitals vit in vitals.Vitals)
//        {
//            vital.Add(vit);

//        }

//        patientWarning = vital;
//    }
//}
