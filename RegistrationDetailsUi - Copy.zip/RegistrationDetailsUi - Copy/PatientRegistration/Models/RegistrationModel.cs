﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientRegistration.Models
{
    class RegistrationModel : INotifyPropertyChanged
    {

        private string patientId;
        public string PatientID
        {
            get { return patientId; }
            set
            {
                patientId = value;
                OnPropertyChanged("PatientID");
            }
        }

        private string patientName;

        public string PatientName
        {
            get { return patientName; }
            set { patientName = value;
                OnPropertyChanged("PatientName");
            }
        }

        private long patientPhone;

        public long PatientPhone
        {
            get { return patientPhone; }
            set { patientPhone = value;
                OnPropertyChanged("PatientPhone");
            }
        }

        private string patientAddress;

        public string PatientAddress
        {
            get { return patientAddress; }
            set { patientAddress = value;
                OnPropertyChanged("PatientAddress");
            }
        }

        private long emergencyContact;

        public long EmergencyContact
        {
            get { return emergencyContact; }
            set { emergencyContact = value;
                OnPropertyChanged("EmergencyContact");
            }
        }

        private string email;

        public string Email
        {
            get { return email; }
            set { email = value;
                OnPropertyChanged("Email");
            }
        }

        private PatientRegistrationService.BloodType bloodType;
                
        public PatientRegistrationService.BloodType BloodType
        {
            get { return bloodType; }
            set { bloodType = value;
                OnPropertyChanged("BloodType");
            }
        }


        private void OnPropertyChanged(string v)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(v));
        }

        public event PropertyChangedEventHandler PropertyChanged;


    }
}
