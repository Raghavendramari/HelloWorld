﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientRegistration.Models
{
    class DoctorRegistrationModel : INotifyPropertyChanged
    {

        private string doctorID;
        public string DoctorID
        {
            get { return doctorID; }
            set
            {
                doctorID = value;
                OnPropertyChanged("DoctorID");
            }
        }

        private string doctorName;

        public string DoctorName
        {
            get { return doctorName; }
            set
            {
                doctorName = value;
                OnPropertyChanged("DoctorName");
            }
        }

        private long doctorPhone;

        public long DoctorPhone
        {
            get { return doctorPhone; }
            set
            {
                doctorPhone = value;
                OnPropertyChanged("DoctorPhone");
            }
        }

        private string doctorAddress;

        public string DoctorAddress
        {
            get { return doctorAddress; }
            set
            {
                doctorAddress = value;
                OnPropertyChanged("DoctorAddress");
            }
        }



        private string email;

        public string Email
        {
            get { return email; }
            set
            {
                email = value;
                OnPropertyChanged("Email");
            }
        }

        private DoctorRegistrationService.DoctorStatus doctorstatus;

        public DoctorRegistrationService.DoctorStatus Doctorstatus
        {
            get { return doctorstatus; }
            set
            {
                doctorstatus = value;
                OnPropertyChanged("Doctorstatus");
            }
        }

        private DoctorRegistrationService.HospitalDepartment hospitaldepartment;

        public DoctorRegistrationService.HospitalDepartment Hospitaldepartment
        {
            get { return hospitaldepartment; }
            set
            {
                hospitaldepartment = value;
                OnPropertyChanged("Hospitaldepartment");
            }
        }


        private void OnPropertyChanged(string v)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(v));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
