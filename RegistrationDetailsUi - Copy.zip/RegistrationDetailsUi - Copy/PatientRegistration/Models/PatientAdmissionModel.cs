﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientRegistration.Models
{
    class PatientAdmissionModel : INotifyPropertyChanged
    {
        private PatientAdmissionService.HospitalBed hospitalBed;

        public PatientAdmissionService.HospitalBed HospitalBed
        {
            get { return hospitalBed; }
            set
            {
                hospitalBed = value;
                OnPropertyChanged("HospitalBed");
            }
        }

        
        private PatientAdmissionService.Device[] devices;

        public PatientAdmissionService.Device[] Devices
        {
            get { return devices; }
            set
            {
                devices = value;
                OnPropertyChanged("Devices");
            }
        }

        private PatientAdmissionService.Device device;

        public PatientAdmissionService.Device Device
        {
            get { return device; }
            set { device = value;
                OnPropertyChanged("Device");
            }
        }

        private string patientId;

        public string PatientId
        {
            get { return patientId; }
            set
            {
                patientId = value;
                OnPropertyChanged("PatientId");
            }
        }

        private string doctorId;

        public string DoctorId
        {
            get { return doctorId; }
            set
            {
                doctorId = value;
                OnPropertyChanged("DoctorId");
            }
        }

        private string illness;

        public string Illness
        {
            get { return illness; }
            set
            {
                illness = value;
                OnPropertyChanged("Illness");
            }
        }

        private string diagnosis;

        public string Diagnosis
        {
            get { return diagnosis; }
            set
            {
                diagnosis = value;
                OnPropertyChanged("Diagnosis");
            }
        }

        private string admissionTime;

        public string AdmissionTime
        {
            get { return admissionTime; }
            set
            {
                admissionTime = value;
                OnPropertyChanged("AdmissionTime");
            }
        }

        //private bool muteAlert;

        //public bool MuteAlert
        //{
        //    get { return muteAlert; }
        //    set
        //    {
        //        muteAlert = value;
        //        OnPropertyChanged("MuteAlert");
        //    }
        //}


        private void OnPropertyChanged(string v)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(v));
        }
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
