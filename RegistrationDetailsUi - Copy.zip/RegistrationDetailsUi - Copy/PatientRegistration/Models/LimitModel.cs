﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientRegistration.Models
{
    class LimitModel : INotifyPropertyChanged
    {

        private double minValue; 

        public double MinValue
        {
            get { return minValue; }
            set { minValue = value;
                OnPropertyChanged("MinValue");
            }
        }

        private double maxValue;

        public double MaxValue
        {
            get { return maxValue; }
            set { maxValue = value;
                OnPropertyChanged("MaxValue");
            }
        }

        private string message;

        public string Message
        {
            get { return message; }
            set { message = value;
                OnPropertyChanged("Message");
            }
        }

        private DeviceRegistrationService.LimitType type;

        public DeviceRegistrationService.LimitType Type
        {
            get { return type; }
            set { type = value;
                OnPropertyChanged("Type");
            }
        }





        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string v)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(v));
        }
    }
}
