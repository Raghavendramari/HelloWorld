﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientRegistration.Models
{
    class BedRegistrationModel : INotifyPropertyChanged
    {


        private string campus;
        public string Campus
        {
            get { return campus; }
            set
            {
                campus = value;
                OnPropertyChanged("Campus");
            }
        }

        private string floor;

        public string Floor
        {
            get { return floor; }
            set
            {
                floor = value;
                OnPropertyChanged("Floor");
            }
        }

        private string wing;

        public string Wing
        {
            get { return wing; }
            set
            {
                wing = value;
                OnPropertyChanged("Wing");
            }
        }

        private string roomnumber;

        public string RoomNumber
        {
            get { return roomnumber; }
            set
            {
                roomnumber = value;
                OnPropertyChanged("RoomNumber");
            }
        }



        private int bednumber;

        public int BedNumber
        {
            get { return bednumber; }
            set
            {
                bednumber = value;
                OnPropertyChanged("BedNumber");
            }
        }
        private string occupancy;

        public string Occupancy
        {
            get { return occupancy; }
            set
            {
                occupancy = value;
                OnPropertyChanged("Occupancy");
            }
        }

        private void OnPropertyChanged(string v)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(v));
        }

        public event PropertyChangedEventHandler PropertyChanged;

    }
}
