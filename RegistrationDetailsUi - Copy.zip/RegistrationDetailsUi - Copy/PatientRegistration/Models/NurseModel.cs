﻿using PatientRegistration.NurseMonitoringService;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientRegistration.Models
{
    public class NurseModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(name));
        }

        private string PatientID { get; set; }
        public string patientID
        {
            get { return PatientID; }
            set
            {
                PatientID = value;
                OnPropertyChanged("patientID");
            }
        }


        private List<Vitals> _Vitals { get; set; }

        public List<Vitals> _vitals
        {
            get { return _Vitals; }
            set
            {
                _Vitals = value;
                OnPropertyChanged("_vitals");
            }
        }
















        //public Dictionary<string, List<PatientAlert>> patientAlert = new Dictionary<string, List<PatientAlert>>();

        //public Dictionary<string, List<PatientAlert>> PatientAlert
        //{
        //    get
        //    {
        //        if(patientAlert==null)
        //        {
        //            patientAlert = new Dictionary<string, List<PatientAlert>>();
        //        }
        //        return patientAlert;

        //    }
        //    set
        //    {
        //        if (patientAlert == null)
        //        {
        //            patientAlert = new Dictionary<string, List<PatientAlert>>();
        //        }
        //        patientAlert.Clear();
        //        foreach(var item in value)
        //        {
        //            patientAlert.Add("" , item);
        //        }

        //    }
        //}









    }
}
