﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientRegistration.Models
{
    class DeviceRegistrationModel:INotifyPropertyChanged
    {

        private string deviceID;

        public string DeviceID
        {
            get { return deviceID; }
            set { deviceID = value;
                OnPropertyChanged("DeviceID");
            }
        }

        private double minInputValue;

        public double MinInputValue
        {
            get { return minInputValue; }
            set { minInputValue = value;
                OnPropertyChanged("MinInputValue");
            }
        }

        private double maxInputValue;

        public double MaxInputValue
        {
            get { return maxInputValue; }
            set
            {
                maxInputValue = value;
                OnPropertyChanged("MaxInputValue");
            }
        }

        //private string minValue;

        //public string MinValue
        //{
        //    get { return minValue; }
        //    set { minValue = value;
        //        OnPropertyChanged("MinValue");
        //    }
        //}

        //private string maxValue;

        //public string MaxValue
        //{
        //    get { return maxValue; }
        //    set
        //    {
        //        maxValue = value;
        //        OnPropertyChanged("MaxValue");
        //    }
        //}



        private DeviceRegistrationService.Limits limit;

        public DeviceRegistrationService.Limits Limit
        {
            get { return limit; }
            set
            {
                limit = value;
                OnPropertyChanged("Limit");
            }
        }

        private DeviceRegistrationService.Limits[] limits;

        public DeviceRegistrationService.Limits[] Limits
        {
            get { return limits; }
            set
            {
                limits = value;
                OnPropertyChanged("Limits");
            }
        }




        private void OnPropertyChanged(string v)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(v));
        }

        public event PropertyChangedEventHandler PropertyChanged;

    }
}
