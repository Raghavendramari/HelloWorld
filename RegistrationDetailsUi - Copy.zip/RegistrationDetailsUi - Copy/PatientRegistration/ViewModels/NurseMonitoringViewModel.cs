﻿using PatientRegistration.Models;
using PatientRegistration.NurseMonitoringService;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientRegistration.ViewModels
{
    public class NurseMonitoringViewModel : INurseMonitoringServiceCallback, INotifyPropertyChanged
    {
        public NurseModel nurse = new NurseModel();

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(name));
        }



        
        public string PatID
        {
            get { return nurse.patientID; }
            set
            {
                nurse.patientID = value;
                OnPropertyChanged("PatID");
            }
        }




        public List<Vitals> _PatientVitals
        {
            get { return nurse._vitals; }
            set
            {
                nurse._vitals = value;
                OnPropertyChanged("_PaientVitals");
            }
        }



        public void ReceiveVitals(PatientVitals vitals)
        {

            PatID = vitals.PatientId;

            foreach (var vital in vitals.Vitals)
            {
                _PatientVitals.Add(vital);
            }
            OnPropertyChanged("_PatientVitals");


        }

        public Dictionary<string, List<Vitals>> patientVitals { get; set; }

        public void ReceiveAlerts(PatientAlert alert)
        {
            PatientAlert patientAlert = new PatientAlert();
            string _patientid = patientAlert.PatientId;
            Dictionary<string, List<DeviceAlert>> patientcriticalAlerts = new Dictionary<string, List<DeviceAlert>>();
            List<DeviceAlert> deviceAlertslist = new List<DeviceAlert>();
            foreach (var alerts in patientAlert.CriticalAlerts)
            {
                deviceAlertslist.Add(alerts);
            }
            patientcriticalAlerts.Add(_patientid, deviceAlertslist);
            Dictionary<string, List<DeviceAlert>> patientwarningAlerts = new Dictionary<string, List<DeviceAlert>>();
            List<DeviceAlert> deviceAlertslist1 = new List<DeviceAlert>();
            foreach (var alerts in patientAlert.WarningAlerts)
            {
                deviceAlertslist1.Add(alerts);
            }
            patientwarningAlerts.Add(_patientid, deviceAlertslist1);
        }
    }
}
