﻿using PatientRegistration.Models;
using PatientRegistration.ViewModels.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace PatientRegistration.ViewModels
{
    class BedRegistrationVM
    {
        public BedRegistrationModel bedregistrationModel { get; set; }
        public ICommand Bed_RegisterCommand { get; set; }
        public ICommand Bed_UpdateCommand { get; set; }
        public ICommand Bed_DeleteCommand { get; set; }
        public ICommand Bed_ReadAllCommand { get; set; }

        public BedRegistrationVM()
        {
            bedregistrationModel = new Models.BedRegistrationModel();

            Bed_RegisterCommand = new Command(Bed_RegisterFunc, IsCondition);
            Bed_UpdateCommand = new Command(Bed_UpdateFunc, IsCondition);
            Bed_DeleteCommand = new Command(Bed_DeleteFunc, IsCondition);
            Bed_ReadAllCommand = new Command(Bed_ReadAllFunc, IsCondition);
        }

        private bool IsCondition(object parameter)
        {
            return true;
        }

        private void Bed_RegisterFunc()
        {
            BedRegistrationService.HospitalBedRegistrationServiceClient bed_client = new BedRegistrationService.HospitalBedRegistrationServiceClient();
            PatientRegistration.BedRegistrationService.HospitalBed temp = new BedRegistrationService.HospitalBed();
            temp.Campus = bedregistrationModel.Campus;
            temp.Floor = bedregistrationModel.Floor;
            temp.Wing = bedregistrationModel.Wing;
            temp.RoomNumber = bedregistrationModel.RoomNumber;
            temp.BedNumber = bedregistrationModel.BedNumber;
            bed_client.RegisterNewBeds(temp);
        }

        private void Bed_UpdateFunc()
        {
            BedRegistrationService.HospitalBedRegistrationServiceClient bed_client = new BedRegistrationService.HospitalBedRegistrationServiceClient();
            PatientRegistration.BedRegistrationService.HospitalBed temp = new BedRegistrationService.HospitalBed();
            temp.Campus = bedregistrationModel.Campus;
            temp.Floor = bedregistrationModel.Floor;
            temp.Wing = bedregistrationModel.Wing;
            temp.RoomNumber = bedregistrationModel.RoomNumber;
            temp.BedNumber = bedregistrationModel.BedNumber;
            temp.Occupancy = bedregistrationModel.Occupancy;
            bed_client.UpdateBedOccupancy(temp);
        }

        private void Bed_DeleteFunc()
        {
            BedRegistrationService.HospitalBedRegistrationServiceClient bed_client = new BedRegistrationService.HospitalBedRegistrationServiceClient();
            PatientRegistration.BedRegistrationService.HospitalBed temp = new BedRegistrationService.HospitalBed();
            temp.BedNumber = bedregistrationModel.BedNumber;
            temp.Campus = bedregistrationModel.Campus;
            temp.Floor = bedregistrationModel.Floor;
            temp.RoomNumber = bedregistrationModel.RoomNumber;
            temp.Wing = bedregistrationModel.Wing;
            bed_client.DeleteBeds(temp);

        }

        private void Bed_ReadAllFunc()
        {
            BedRegistrationService.HospitalBedRegistrationServiceClient bed_client = new BedRegistrationService.HospitalBedRegistrationServiceClient();
            var beds = bed_client.ReadAllBeds();
            //ReadAllBeds readAllBeds = new ReadAllBeds();
            //readAllBeds.Show();

        }

    }
}
