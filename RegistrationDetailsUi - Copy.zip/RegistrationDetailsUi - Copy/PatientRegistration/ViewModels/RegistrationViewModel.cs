﻿using PatientRegistration.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using PatientRegistration.ViewModels.Commands;
using System.Windows;

namespace PatientRegistration.ViewModels
{
    class RegistrationViewModel
    {

        public RegistrationModel patientRegistrationModel { get; set; }

        public ICommand AddCommand { get; set; }
        public ICommand UpdateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand ReadAllPatientsCommand { get; set; }
        public ICommand ReadPatientCommand { get; set; }

        public RegistrationViewModel()
        {
            patientRegistrationModel = new Models.RegistrationModel();
            AddCommand = new Command(AddPatientData, IsCondition);
            UpdateCommand = new Command(UpdatePatientData, IsCondition);
            DeleteCommand = new Command(DeletePatientData, IsCondition);
            
            ReadPatientCommand = new Command(ReadPatient, IsCondition);
        }

        private bool IsCondition(object parameter)
        {
            return true;
        }

        private void ReadPatient()
        {
            PatientRegistrationService.PatientRegistrationServiceClient obj = new PatientRegistrationService.PatientRegistrationServiceClient();
            string id = patientRegistrationModel.PatientID;
            PatientRegistrationService.Patient patient = obj.ReadPatient(id);
            MessageBox.Show("Patient Name:" + patient.Name + "\nPatient Id: " + patient.PatientId + "\nPatient Phone: " + patient.Phone+"\nBlood Type: "+patient.BloodType+"\nPatient Email: "+patient.Email+"\nEmergency Contact: "+patient.EmergencyContact+ "\nPatient Address: "+patient.Address);
            
        }

        private void AddPatientData()
        {
            PatientRegistrationService.PatientRegistrationServiceClient obj = new PatientRegistrationService.PatientRegistrationServiceClient();
                
                PatientRegistration.PatientRegistrationService.Patient temp = new PatientRegistrationService.Patient();                
                temp.BloodType = patientRegistrationModel.BloodType;
                temp.Email = patientRegistrationModel.Email;
                temp.EmergencyContact = patientRegistrationModel.EmergencyContact;                
                temp.Address = patientRegistrationModel.PatientAddress;
                temp.PatientId = patientRegistrationModel.PatientID;
                temp.Name = patientRegistrationModel.PatientName;
                temp.Phone = patientRegistrationModel.PatientPhone;
                temp.PreviousAdmissions = new PatientRegistrationService.AdmissionHistory[0];
                obj.RegisterNewPatient(temp);
        }

        private void UpdatePatientData()
        {
            PatientRegistrationService.PatientRegistrationServiceClient obj = new PatientRegistrationService.PatientRegistrationServiceClient();            
            PatientRegistration.PatientRegistrationService.Patient temp = new PatientRegistrationService.Patient();            
            temp.BloodType = patientRegistrationModel.BloodType;
            temp.Email = patientRegistrationModel.Email;
            temp.EmergencyContact = patientRegistrationModel.EmergencyContact;
            temp.Address = patientRegistrationModel.PatientAddress;
            temp.PatientId = patientRegistrationModel.PatientID;
            temp.Name = patientRegistrationModel.PatientName;
            temp.Phone = patientRegistrationModel.PatientPhone;
            temp.PreviousAdmissions = new PatientRegistrationService.AdmissionHistory[0];
            temp.PreviousAdmissions = (obj.ReadPatient(patientRegistrationModel.PatientID)).PreviousAdmissions;
            obj.UpdatePatient(temp);        
        }

        private void DeletePatientData()
        {
            PatientRegistrationService.PatientRegistrationServiceClient obj = new PatientRegistrationService.PatientRegistrationServiceClient();
            obj.DeletePatient(patientRegistrationModel.PatientID);
        }
    }
}
