﻿using PatientRegistration.Models;
using PatientRegistration.ViewModels.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace PatientRegistration.ViewModels
{
    class DoctorRegistrationVM
    {
        public DoctorRegistrationModel doctorregistrationModel { get; set; }
        public ICommand Doctor_RegisterCommand { get; set; }
        public ICommand Doctor_UpdateCommand { get; set; }
        public ICommand Doctor_DeleteCommand { get; set; }
        public ICommand Doctor_ReadAllCommand { get; set; }

        public DoctorRegistrationVM()
        {
            doctorregistrationModel = new Models.DoctorRegistrationModel();

            Doctor_RegisterCommand = new Command(Doctor_RegisterFunc, IsCondition);
            Doctor_UpdateCommand = new Command(Doctor_UpdateFunc, IsCondition);
            Doctor_DeleteCommand = new Command(Doctor_DeleteFunc, IsCondition);            
        }



        private bool IsCondition(object parameter)
        {
            return true;
        }

        private void Doctor_RegisterFunc()
        {
            DoctorRegistrationService.DoctorRegistrationServiceClient doctor_client = new DoctorRegistrationService.DoctorRegistrationServiceClient();
            PatientRegistration.DoctorRegistrationService.Doctor temp = new DoctorRegistrationService.Doctor();
            temp.DoctorId = doctorregistrationModel.DoctorID;
            temp.Name = doctorregistrationModel.DoctorName;
            temp.Phone = doctorregistrationModel.DoctorPhone;
            temp.Address = doctorregistrationModel.DoctorAddress;
            temp.Email = doctorregistrationModel.Email;
            temp.Status = doctorregistrationModel.Doctorstatus;
            temp.Department = doctorregistrationModel.Hospitaldepartment;
            doctor_client.RegisterNewDoctor(temp);

        }

        private void Doctor_UpdateFunc()
        {

            DoctorRegistrationService.DoctorRegistrationServiceClient doctor_client = new DoctorRegistrationService.DoctorRegistrationServiceClient();
            PatientRegistration.DoctorRegistrationService.Doctor temp = new DoctorRegistrationService.Doctor();
            temp.DoctorId = doctorregistrationModel.DoctorID;
            temp.Name = doctorregistrationModel.DoctorName;
            temp.Phone = doctorregistrationModel.DoctorPhone;
            temp.Address = doctorregistrationModel.DoctorAddress;
            temp.Email = doctorregistrationModel.Email;
            temp.Status = doctorregistrationModel.Doctorstatus;
            temp.Department = doctorregistrationModel.Hospitaldepartment;
            doctor_client.UpdateDoctor(temp);
        }

        private void Doctor_DeleteFunc()
        {
            DoctorRegistrationService.DoctorRegistrationServiceClient doctor_client = new DoctorRegistrationService.DoctorRegistrationServiceClient();
            string id = doctorregistrationModel.DoctorID;
            doctor_client.DeleteDoctor(id);
        }

    }
}
