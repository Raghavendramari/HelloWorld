﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using PatientRegistration.Models;
using PatientRegistration.ViewModels.Commands;

namespace PatientRegistration.ViewModels
{
    class DeviceRegistrationViewModel
    {
        public LimitModel limitModel { get; set; }
        List<DeviceRegistrationService.Limits> limits= new List<DeviceRegistrationService.Limits>();
        public DeviceRegistrationModel deviceRegistrationModel { get; set; }

        public ICommand AddCommand { get; set; }
        public ICommand UpdateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }
        public ICommand ReadAllDevicesCommand { get; set; }
        public ICommand AddLimitCommand { get; set; }
        public ICommand ReadDeviceCommand { get; set; }


        public DeviceRegistrationViewModel()
        {
            limitModel = new LimitModel();
            deviceRegistrationModel = new DeviceRegistrationModel();
            AddCommand = new Command(AddDeviceData, IsCondition);
            UpdateCommand = new Command(UpdateDeviceData, IsCondition);
            DeleteCommand = new Command(DeleteDeviceData, IsCondition);
            AddLimitCommand = new Command(AddLimit, IsCondition);
            ReadDeviceCommand = new Command(ReadDevice, IsCondition);
        }

        private bool IsCondition(object parameter)
        {
            return true;
        }

        private void ReadDevice()
        {
            DeviceRegistrationService.DeviceRegistrationServiceClient obj = new DeviceRegistrationService.DeviceRegistrationServiceClient();
            string id = deviceRegistrationModel.DeviceID;
            DeviceRegistrationService.Device device = obj.ReadDevice(id);            
            MessageBox.Show("Device Id: " + device.DeviceId + "\nMax Value: " + device.MaxInputValue + "\nMin Value: " + device.MinInputValue + "\nDevice Limits: " + device.Limits);

        }

        private void AddLimit()
        {            
            DeviceRegistrationService.Limits limit = new DeviceRegistrationService.Limits();
            limit.MaxValue = limitModel.MaxValue;
            limit.MinValue = limitModel.MinValue;
            limit.Message = limitModel.Message;
            limit.Type = limitModel.Type;
            limits.Add(limit);
        }

        private void AddDeviceData()
        {
            DeviceRegistrationService.DeviceRegistrationServiceClient obj = new DeviceRegistrationService.DeviceRegistrationServiceClient();            
            DeviceRegistrationService.Device temp = new DeviceRegistrationService.Device();
            temp.DeviceId = deviceRegistrationModel.DeviceID;
            temp.Limits = limits.ToArray();
            temp.MaxInputValue = deviceRegistrationModel.MaxInputValue;
            temp.MinInputValue = deviceRegistrationModel.MinInputValue;
            obj.RegisterNewDevice(temp);
        }

        private void UpdateDeviceData()
        {
            DeviceRegistrationService.DeviceRegistrationServiceClient obj = new DeviceRegistrationService.DeviceRegistrationServiceClient();
            DeviceRegistrationService.Device temp = new DeviceRegistrationService.Device();
            temp.DeviceId = deviceRegistrationModel.DeviceID;
            temp.Limits = limits.ToArray<DeviceRegistrationService.Limits>();
            temp.MaxInputValue = deviceRegistrationModel.MaxInputValue;
            temp.MinInputValue = deviceRegistrationModel.MinInputValue;
            obj.UpdateDevice(temp);            
        }

        private void DeleteDeviceData()
        {
            DeviceRegistrationService.DeviceRegistrationServiceClient obj = new DeviceRegistrationService.DeviceRegistrationServiceClient();
            string id = deviceRegistrationModel.DeviceID;
            obj.DeleteDevice(id);            
        }

        private void ReadAllDevicesData()
        {
            DeviceRegistrationService.DeviceRegistrationServiceClient obj = new DeviceRegistrationService.DeviceRegistrationServiceClient();
            var list = obj.ReadAllDevices();


        }



    }
}
