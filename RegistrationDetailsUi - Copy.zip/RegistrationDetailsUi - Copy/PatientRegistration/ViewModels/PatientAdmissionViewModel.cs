﻿using Newtonsoft.Json;
using PatientRegistration.BedRegistrationService;
using PatientRegistration.DeviceRegistrationService;
using PatientRegistration.DoctorRegistrationService;
using PatientRegistration.Models;
using PatientRegistration.PatientRegistrationService;
using PatientRegistration.ViewModels.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;


namespace PatientRegistration.ViewModels
{
    class PatientAdmissionViewModel
    {
        public PatientAdmissionModel patientAdmissionModel { get; set; }
        public BedRegistrationModel bedRegistrationModel { get; set; }
        public List<PatientAdmissionService.Device> devices = new List<PatientAdmissionService.Device>();
        public List<PatientAdmissionService.Device> devices2 = new List<PatientAdmissionService.Device>();
        public PatientAdmissionService.Device device = new PatientAdmissionService.Device();
        public PatientAdmissionService.Device device2 = new PatientAdmissionService.Device();
        public PatientAdmissionService.Limits limits = new PatientAdmissionService.Limits();
        public PatientAdmissionService.Limits limits1 = new PatientAdmissionService.Limits();
        public PatientAdmissionService.Limits limits2 = new PatientAdmissionService.Limits();

        public PatientAdmissionService.Limits limits11 = new PatientAdmissionService.Limits();
        public PatientAdmissionService.Limits limits12 = new PatientAdmissionService.Limits();
        public PatientAdmissionService.Limits limits13 = new PatientAdmissionService.Limits();

        public List<PatientAdmissionService.Limits> limitsList = new List<PatientAdmissionService.Limits>();
        public List<PatientAdmissionService.Limits> limitsList1 = new List<PatientAdmissionService.Limits>();



        public ICommand AddCommand { get; set; }
        public ICommand UpdateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }        
        public ICommand ViewAdmissionCommand { get; set; }
        public ICommand AddDeviceCommand { get; set; }
        public ICommand RemoveDeviceCommand { get; set; }        

        public PatientAdmissionViewModel()
        {
            bedRegistrationModel = new Models.BedRegistrationModel();
            patientAdmissionModel = new Models.PatientAdmissionModel();
            AddCommand = new Command(AdmitPatient, IsCondition);
            UpdateCommand = new Command(UpdatePatient, IsCondition);
            DeleteCommand = new Command(DeletePatient, IsCondition);
            AddDeviceCommand = new Command(AddDevice, IsCondition);
            RemoveDeviceCommand = new Command(RemoveDevice, IsCondition);
            ViewAdmissionCommand = new Command(ViewAdmission, IsCondition);
        }

        private bool IsCondition(object parameter)
        {
            return true;
        }


        
        private void ViewAdmission()
        {
            PatientAdmissionService.PatientAdmissionServiceClient obj = new PatientAdmissionService.PatientAdmissionServiceClient();
            string id = patientAdmissionModel.PatientId;
            PatientAdmissionService.PatientAdmission patientAdmission = obj.ReadAdmission(id);
            MessageBox.Show("PatientId: " + patientAdmission.PatientId + " PatientAdmissionTime: " + patientAdmission.AdmissionTime + " PatientBed: " + patientAdmission.Bed + " PatientDevices " + patientAdmission.Devices + patientAdmission.Diagnosis + patientAdmission.DoctorId + patientAdmission.Illness);
        }
        

        private void AddDevice()
        {
            PatientAdmissionService.PatientAdmissionServiceClient obj = new PatientAdmissionService.PatientAdmissionServiceClient();            
            string patientId = patientAdmissionModel.PatientId;
            string deviceId = patientAdmissionModel.Device.DeviceId;
            PatientAdmissionService.Device device = patientAdmissionModel.Device;
            obj.AddDeviceToPatient(patientId,deviceId,device);
        }

        private void RemoveDevice()
        {
            PatientAdmissionService.PatientAdmissionServiceClient obj = new PatientAdmissionService.PatientAdmissionServiceClient();
            string patientId = patientAdmissionModel.PatientId;
            string deviceId = patientAdmissionModel.Device.DeviceId;
            obj.RemoveDeviceFromPatient(patientId, deviceId);
        }

        private void AdmitPatient()
        {
            PatientAdmissionService.PatientAdmissionServiceClient obj = new PatientAdmissionService.PatientAdmissionServiceClient();
            BedRegistrationService.HospitalBedRegistrationServiceClient hospitalBedRegistrationServiceClient = new BedRegistrationService.HospitalBedRegistrationServiceClient();
            PatientAdmissionService.HospitalBed hospitalBed = new PatientAdmissionService.HospitalBed();
            PatientAdmissionService.PatientAdmission temp = new PatientAdmissionService.PatientAdmission();
            temp.AdmissionTime = patientAdmissionModel.AdmissionTime;


            device.DeviceId = "Thermometer";
            device.MaxInputValue = 110;
            device.MinInputValue = 80;

            limits.MaxValue = 100;
            limits.MinValue = 80;
            limits.Type = PatientAdmissionService.LimitType.Normal;
            limits.Message = "Normal, don't worry";

            limits1.MaxValue = 105;
            limits1.MinValue = 100;
            limits1.Type = PatientAdmissionService.LimitType.Warning;
            limits.Message = "Warning";

            limits2.MaxValue = 110;
            limits2.MinValue = 105;
            limits2.Type = PatientAdmissionService.LimitType.Critical;
            limits2.Message = "Critical";

            limitsList.Add(limits);
            limitsList.Add(limits1);
            limitsList.Add(limits2);

            device.Limits = limitsList.ToArray();

            devices.Add(device);

            device2.DeviceId = "HeartRate";
            device2.MaxInputValue = 150;
            device2.MinInputValue = 80;

            limits11.MaxValue = 100;
            limits11.MinValue = 80;
            limits11.Type = PatientAdmissionService.LimitType.Normal;
            limits11.Message = "Normal, don't worry";

            limits12.MaxValue = 120;
            limits12.MinValue = 100;
            limits12.Type = PatientAdmissionService.LimitType.Warning;
            limits12.Message = "Warning";

            limits13.MaxValue = 150;
            limits13.MinValue = 120;
            limits13.Type = PatientAdmissionService.LimitType.Critical;
            limits13.Message = "Critical";

            limitsList1.Add(limits11);
            limitsList1.Add(limits12);
            limitsList1.Add(limits13);

            device2.Limits = limitsList1.ToArray();

            devices.Add(device2);

            hospitalBed.Wing= bedRegistrationModel.Wing;
            hospitalBed.Campus = bedRegistrationModel.Campus;
            hospitalBed.Floor = bedRegistrationModel.Floor;
            hospitalBed.RoomNumber = bedRegistrationModel.RoomNumber;
            hospitalBed.BedNumber = bedRegistrationModel.BedNumber;
            
            BedRegistrationService.HospitalBed[] hospitalBeds = hospitalBedRegistrationServiceClient.ReadEmptyBeds(hospitalBed.Campus);

            var selected = hospitalBeds.Where((e) => e.BedNumber.Equals(hospitalBed.BedNumber) && e.Campus.Equals(hospitalBed.Campus) && e.Floor.Equals(hospitalBed.Floor) && e.RoomNumber.Equals(hospitalBed.RoomNumber) && e.Wing.Equals(hospitalBed.Wing));
            if (selected == null)
                MessageBox.Show("Sorry, this bed is unavailable right now");
            temp.Bed = hospitalBed;
            devices.Add(patientAdmissionModel.Device);
            temp.Devices = devices.ToArray();
            temp.Diagnosis = patientAdmissionModel.Diagnosis;
            temp.DoctorId = patientAdmissionModel.DoctorId;
            temp.Illness = patientAdmissionModel.Illness;
            temp.PatientId = patientAdmissionModel.PatientId;
            NurseMonitoringService.NurseMonitoringServiceClient nurseMonitoringServiceClient = new NurseMonitoringService.NurseMonitoringServiceClient(new System.ServiceModel.InstanceContext(new NurseMonitoringViewModel()));            
            string locationId = hospitalBed.Campus + "-" + hospitalBed.Floor + "-" + hospitalBed.Wing;

            nurseMonitoringServiceClient.SubscribeToVitals(temp.PatientId, locationId);
            obj.AdmitPatient(temp);
        }

        private void UpdatePatient()
        {
            PatientAdmissionService.PatientAdmissionServiceClient obj = new PatientAdmissionService.PatientAdmissionServiceClient();
            PatientAdmissionService.PatientAdmission temp = new PatientAdmissionService.PatientAdmission();
            temp.AdmissionTime = patientAdmissionModel.AdmissionTime;
            temp.Bed = patientAdmissionModel.HospitalBed;
            temp.Devices = patientAdmissionModel.Devices;
            temp.Diagnosis = patientAdmissionModel.Diagnosis;
            temp.DoctorId = patientAdmissionModel.DoctorId;
            temp.Illness = patientAdmissionModel.Illness;
            
            temp.PatientId = patientAdmissionModel.PatientId;
            obj.AdmitPatient(temp);
        }

        private void DeletePatient()
        {
            PatientAdmissionService.PatientAdmissionServiceClient obj = new PatientAdmissionService.PatientAdmissionServiceClient();
            string id = patientAdmissionModel.PatientId;
            obj.DischargePatient(id);
        }


}

}
