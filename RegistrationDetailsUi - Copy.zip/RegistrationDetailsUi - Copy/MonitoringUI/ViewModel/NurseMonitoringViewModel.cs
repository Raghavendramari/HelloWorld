﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MonitoringUI.ViewModel;
using System.Windows.Input;
using MonitoringUI.NurseMonitoringService;

namespace MonitoringUI.ViewModel
{
    public class NurseMonitoringViewModel
    {
       // public ICommand ReceiveAlerts_command { get; set; }

        //public NurseMonitoringViewModel()
        //{
        //    ReceiveAlerts_command = new Command(ReceiveAlerts_Func, IsCondition);
        //}

        private bool IsCondition(object obj)
        {
            return true;
        }

        public void ReceiveAlerts_Func()
        {
            
            PatientAlert patientAlert = new PatientAlert();
            string _patientid = patientAlert.PatientId;
            Dictionary<string, List<DeviceAlert>> patientcriticalAlerts = new Dictionary<string, List<DeviceAlert>>();
            List<DeviceAlert> deviceAlertslist = new List<DeviceAlert>();
            foreach(var alert in patientAlert.CriticalAlerts)
            {
                deviceAlertslist.Add(alert);
            }
            patientcriticalAlerts.Add(_patientid, deviceAlertslist);


           


            Dictionary<string, List<DeviceAlert>> patientwarningAlerts = new Dictionary<string, List<DeviceAlert>>();
            List<DeviceAlert> deviceAlertslist1 = new List<DeviceAlert>();
            foreach (var alert in patientAlert.WarningAlerts)
            {
                deviceAlertslist1.Add(alert);
            }
            patientwarningAlerts.Add(_patientid, deviceAlertslist1);
            var client = new NurseMonitoringService.NurseMonitoringServiceClient(new System.ServiceModel.InstanceContext(new NurseMonitoringViewModel()));
            client.SubscribeToPatientAlerts(_patientid);



            client.SubscribeToPatientAlerts("");
        }
    }
}
