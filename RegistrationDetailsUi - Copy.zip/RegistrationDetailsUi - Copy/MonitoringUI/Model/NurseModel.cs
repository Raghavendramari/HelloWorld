﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using MonitoringUI.NurseMonitoringService;

namespace MonitoringUI.Model
{
    class NurseModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private string PatientID;

        public string PatID
        {
            get { return PatientID; }
            set
            {
                PatientID = value;
                OnPropertyChanged("PatID");
            }
        }

        //public Dictionary<string, List<PatientAlert>> patientAlert = new Dictionary<string, List<PatientAlert>>();

        //public Dictionary<string, List<PatientAlert>> PatientAlert
        //{
        //    get
        //    {
        //        if(patientAlert==null)
        //        {
        //            patientAlert = new Dictionary<string, List<PatientAlert>>();
        //        }
        //        return patientAlert;
                    
        //    }
        //    set
        //    {
        //        if (patientAlert == null)
        //        {
        //            patientAlert = new Dictionary<string, List<PatientAlert>>();
        //        }
        //        patientAlert.Clear();
        //        foreach(var item in value)
        //        {
        //            patientAlert.Add("" , item);
        //        }

        //    }
        //}






        private void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(name));
        }



    }
}
