﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RegistrationDetailsUi
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void On_click(object sender, RoutedEventArgs e)
        {
            PatientRegistrationService.PatientRegistrationServiceClient client = new PatientRegistrationService.PatientRegistrationServiceClient();
              PatientRegistrationService.BloodType bloodType;
            PatientRegistrationService.Patient patient = new PatientRegistrationService.Patient();
            patient.PatientId = txtID.Text;
            patient.Name = txtName.Text;
            patient.Phone = long.Parse(txtPhone.Text);
            patient.Address = txtAddress.Text;
            patient.EmergencyContact = long.Parse(txtcontact.Text);
            patient.Email = txtemail.Text;
            patient.BloodType = PatientRegistrationService.BloodType.ABNegative;
            client.RegisterNewPatient(patient);
            int i=1;
             

        }
    }
}
