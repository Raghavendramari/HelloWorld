#include "pch.h"
#include "\BootCamp\CPP training\fin322 - Copy\chatbot1\chatbot1\Header2.h"
#define CATCH_CONFIG_MAIN
#include "Test.hpp"
#include <iostream>

string Vals[17][20] = { {"0","0","0","0","0","0","0","0","0"},
							 {"0","Efficia","CM10","10","NULL","No","8","NULL","NULL"},
							 {"0","Intellivue","MX800","19","No","Yes","NULL","NULL"},
							 {"0","Efficia","CM100","10","NULL","Yes","8","NULL","NULL"},
							 {"0","Efficia","CM12","12","NULL","No","12","NULL","NULL" },
							 {"0","Efficia","CM120","12","NULL","Yes","8","NULL","NULL"},
							 {"0","Efficia","CM150","15","NULL","Yes","12","NULL","NULL"},
							 {"0","Avalon","FM20","6.5","NULL","No","NULL","5.2","Antepartum"},
							 {"0","Avalon","FM30","6.5","NULL","Standard","NULL","5.2","Intrapartum"},
							 {"0","Avalon","FM40","6.5","NULL","Standard","NULL","9","Antepartum"},
							 {"0","Avalon","FM50","6.5","NULL","Standard","NULL","9","Intrapartum"},
							 {"0","Intellivue","MX40","4","Yes","Yes","NULL","NULL","NULL"},
							 {"0","Intellivue","MX400","9","Yes","Yes","NULL","NULL","NULL"},
							 {"0","Intellivue","MX450","12","Yes","Yes","NULL","NULL","NULL"},
							 {"0","Intellivue","MX500","12","Yes","Yes","NULL","NULL","NULL"},
							 {"0","Intellivue","MX550","15","Yes","Yes","NULL","NULL","NULL"},
							 {"0","Intellivue","MX700","15","No","Yes","NULL","NULL","NULL"} };

TEST_CASE("IntellivueBOScreenSize1Test")
{
	
	BusinessLayer obj;

	REQUIRE(true == obj.IntellivueBOScreenSize1(16, 8, Vals, 1));	
	REQUIRE(false == obj.IntellivueBOScreenSize1(0, 8, Vals, 1));	
	REQUIRE(false == obj.IntellivueBOScreenSize1(0, 8, Vals, 2));
	REQUIRE(true == obj.IntellivueBOScreenSize1(16, 8, Vals, 2));
	REQUIRE(true == obj.IntellivueBOScreenSize1(16, 8, Vals, 2));

}

TEST_CASE("IntellivueBOScreenSize2Test")
{
	BusinessLayer obj;

	REQUIRE(true == obj.IntellivueBOScreenSize2(16, 8, Vals, 1));
	REQUIRE(false == obj.IntellivueBOScreenSize2(0, 8, Vals, 1));
	REQUIRE(false == obj.IntellivueBOScreenSize2(0, 8, Vals, 2));
	REQUIRE(true == obj.IntellivueBOScreenSize2(16, 8, Vals, 2));

}

TEST_CASE("IntellivueBOPortability1Test")
{
	BusinessLayer obj;

	REQUIRE(true == obj.IntellivueBOPortability1(16, 8, Vals, 1));
	REQUIRE(false == obj.IntellivueBOPortability1(0, 8, Vals, 1));
	REQUIRE(false == obj.IntellivueBOPortability1(0, 8, Vals, 2));
	REQUIRE(true == obj.IntellivueBOPortability1(16, 8, Vals, 2));

}

TEST_CASE("IntellivueBOPortability2Test")
{
	BusinessLayer obj;

	REQUIRE(true == obj.IntellivueBOPortability2(16, 8, Vals, 1));
	REQUIRE(false == obj.IntellivueBOPortability2(0, 8, Vals, 1));
	REQUIRE(false == obj.IntellivueBOPortability2(0, 8, Vals, 2));
	REQUIRE(true == obj.IntellivueBOPortability2(16, 8, Vals, 2));

}

TEST_CASE("EfficiaBOScreenSize1Test")
{
	BusinessLayer obj;

	REQUIRE(true == obj.EfficiaBOScreenSize1(16, 8, Vals, 1));
	REQUIRE(false == obj.EfficiaBOScreenSize1(0, 8, Vals, 1));
	REQUIRE(false == obj.EfficiaBOScreenSize1(0, 8, Vals, 2));
	REQUIRE(true == obj.EfficiaBOScreenSize1(16, 8, Vals, 2));

}

TEST_CASE("EfficiaBOScreenSize2Test")
{
	BusinessLayer obj;

	REQUIRE(true == obj.EfficiaBOScreenSize2(16, 8, Vals, 1));
	REQUIRE(false == obj.EfficiaBOScreenSize2(0, 8, Vals, 1));
	REQUIRE(false == obj.EfficiaBOScreenSize2(0, 8, Vals, 2));
	REQUIRE(true == obj.EfficiaBOScreenSize2(16, 8, Vals, 2));

}

TEST_CASE("EfficiaBOTOuchScreen1Test")
{
	BusinessLayer obj;

	REQUIRE(true == obj.EfficiaBOTouchScreen1(16, 8, Vals, 1));
	REQUIRE(false == obj.EfficiaBOTouchScreen1(0, 8, Vals, 1));
	REQUIRE(false == obj.EfficiaBOTouchScreen1(0, 8, Vals, 2));
	REQUIRE(true == obj.EfficiaBOTouchScreen1(16, 8, Vals, 2));

}

TEST_CASE("EfficiaBOTOuchScreen2Test")
{
	BusinessLayer obj;

	REQUIRE(true == obj.EfficiaBOTouchScreen2(16, 8, Vals, 1));
	REQUIRE(false == obj.EfficiaBOTouchScreen2(0, 8, Vals, 1));
	REQUIRE(false == obj.EfficiaBOTouchScreen2(0, 8, Vals, 2));
	REQUIRE(true == obj.EfficiaBOTouchScreen2(16, 8, Vals, 2));

}

TEST_CASE("AvalonBOCareStage1Test")
{
	BusinessLayer obj;

	REQUIRE(true == obj.AvalonBOCareStage1(16, 8, Vals, 1));
	REQUIRE(false == obj.AvalonBOCareStage1(0, 8, Vals, 1));
	REQUIRE(false == obj.AvalonBOCareStage1(0, 8, Vals, 2));
	REQUIRE(true == obj.AvalonBOCareStage1(16, 8, Vals, 2));

}

TEST_CASE("AvalonBOCareStage2Test")
{
	BusinessLayer obj;

	REQUIRE(true == obj.AvalonBOCareStage2(16, 8, Vals, 1));
	REQUIRE(false == obj.AvalonBOCareStage2(0, 8, Vals, 1));
	REQUIRE(false == obj.AvalonBOCareStage2(0, 8, Vals, 2));
	REQUIRE(true == obj.AvalonBOCareStage2(16, 8, Vals, 2));

}

TEST_CASE("AvalonBOWeight1Test")
{
	BusinessLayer obj;

	REQUIRE(true == obj.AvalonBOWeight1(16, 8, Vals, 1));
	REQUIRE(false == obj.AvalonBOWeight1(0, 8, Vals, 1));
	REQUIRE(false == obj.AvalonBOWeight1(0, 8, Vals, 2));
	REQUIRE(true == obj.AvalonBOWeight1(16, 8, Vals, 2));

}

TEST_CASE("AvalonBOWeight2Test")
{
	BusinessLayer obj;

	REQUIRE(true == obj.AvalonBOWeight2(16, 8, Vals, 1));
	REQUIRE(false == obj.AvalonBOWeight2(0, 8, Vals, 1));
	REQUIRE(false == obj.AvalonBOWeight2(0, 8, Vals, 2));
	REQUIRE(true == obj.AvalonBOWeight2(16, 8, Vals, 2));

}
//ConsoleApplication1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
//
//#include "pch.h"
//#include <iostream>
//
//int main()
//{
//    std::cout << "Hello World!\n"; 
//}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file

