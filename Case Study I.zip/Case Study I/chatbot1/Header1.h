#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include<sstream>
#include<cstring>
#include "Header.h"

string Values[20][20];
string Values1[20][20];
int cnt = 0;

class BusinessLayer
{
public:
	float ConvertToFloat(string);

	void ReadCSVFile();

	string processing(string s);


	bool IntellivueBOScreenSize1(int row, int col, string Values[][20], int Level);
	bool IntellivueBOScreenSize2(int row, int col, string Values[][20], int Level);

	bool IntellivueBOPortability1(int row, int col, string Values[][20], int Level);
	bool IntellivueBOPortability2(int row, int col, string Values[][20], int Level);

	bool EfficiaBOScreenSize1(int row, int col, string Values[][20], int Level);
	bool EfficiaBOScreenSize2(int row, int col, string Values[][20], int Level);

	bool EfficiaBOTouchScreen1(int row, int col, string Values[][20], int Level);
	bool EfficiaBOTouchScreen2(int row, int col, string Values[][20], int Level);

	bool AvalonBOCareStage1(int row, int col, string Values[][20], int Level);
	bool AvalonBOCareStage2(int row, int col, string Values[][20], int Level);

	bool AvalonBOWeight1(int row, int col, string Values[][20], int Level);
	bool AvalonBOWeight2(int row, int col, string Values[][20], int Level);
};


class FuncImplementation :Func
{
public:

	void IntellivueBOScreenSize(int row, int col, string Values[][20]);

	void IntellivueBOPortability(int row, int col, string Values[][20]);

	void EfficiaBOScreenSize(int row, int col, string Values[][20]);
	
	void EfficiaBOTouchScreen(int row, int col, string Values[][20]);

	void AvalonBOCareStage(int row, int col, string Values[][20]);

	void AvalonBOWeight(int row, int col, string Values[][20]);
	
};

class UIFunction
{
public:
	void InvalidInput();
	void Urban();
	void SemiUrban();
	void ICU();
	void labourcare();
	void icuvslabour();
	void greeting();	
	void Display();	
	bool Level2Test(int level, int test);
};


void BusinessLayer::ReadCSVFile()
{
	ifstream ip;

	ip.open("C:\\BootCamp\\CPP training\\fin322 - Copy - Copy\\chatbot1\\chatbot1\\data.txt");
	if (ip.fail())
	{
		cout << "File Error" << endl;
		exit(1);
	}
	

	string Name;
	string Model;
	string SS;
	string Portability;
	string TouchScreen;
	string NoOfWaveForm;
	string Weight;
	string CareStage;

	while (!ip.eof())
	{
		for (int i = 1; i < 17; i++)
		{
			int j = 1;

			getline(ip, Name, ',');
			if (i == 1)
				Values[i][j] = Name;
			if (i > 1)
				Values[i][j] = processing(Name);
			getline(ip, Model, ',');
			Values[i][j + 1] = Model;
			getline(ip, SS, ',');
			Values[i][j + 2] = SS;

			getline(ip, Portability, ',');
			Values[i][j + 3] = Portability;
			getline(ip, TouchScreen, ',');
			Values[i][j + 4] = TouchScreen;
			getline(ip, NoOfWaveForm, ',');
			Values[i][j + 5] = NoOfWaveForm;
			int NoOfWF;
			std::istringstream iss(NoOfWaveForm);
			iss >> NoOfWF;
			getline(ip, Weight, ',');
			Values[i][j + 6] = Weight;
			getline(ip, CareStage, ',');
			Values[i][j + 7] = CareStage;


		}
	}
}



float BusinessLayer::ConvertToFloat(string SS)
{
	float ScreenSize = std::stof(SS);
	return ScreenSize;

}

string BusinessLayer::processing(string s)
{
	s.erase(0, 1);
	return s;
}


void FuncImplementation::IntellivueBOScreenSize(int row, int col, string Values[][20])
{
	primary:
	cout << "Choose any one of these categories\nA.Small Screen\nB.Large Screen\nC.Go Back" << endl;
	char choice;
	cin >> choice;
	UIFunction obj;
	BusinessLayer object;
	switch (choice)
	{
	case 'A':object.IntellivueBOScreenSize1(row, col,Values,1);
		break;
	case 'B':object.IntellivueBOScreenSize2(row, col,Values,1);
		break;	
	case 'C':
		obj.Urban();
		break;
	default:
		obj.InvalidInput();		
		goto primary;		
	}		
}
bool BusinessLayer::IntellivueBOScreenSize1(int row, int col, string Values[][20],int Level)
{	
	if (row == 0)return false;	
	cout << endl << "Monitors with Screen Size < 10" << endl;
	cnt = 0;
	
	UIFunction obj;
	obj.Display();
	for (int i = 1; i <= row; i++)
	{
		if (Values[i][1] == "Intellivue" && ConvertToFloat(Values[i][3]) < 10)
		{
			cnt++;
			for (int j = 1; j <= col; j++)
			{
				cout << Values[i][j] << "		";
				if (Level == 1)
					Values1[cnt][j] = Values[i][j];
			}
			cout << endl;
		}
	}
	int cnt2 = cnt;	
	if (Level == 1)
	{		
		IntellivueBOPortability1(cnt, col, Values1, 2);
		IntellivueBOPortability2(cnt2, col, Values1, 2);		
	}
	else if (!obj.Level2Test(Level,cnt))
	{
		return false;
	}	
	return true;
}
bool BusinessLayer::IntellivueBOScreenSize2(int row, int col, string Values[][20],int Level)
{
	if (row == 0)return false;	
	cout << endl << "Monitors with Screen Size > 10" << endl;
	cnt = 0;
	UIFunction obj;
	obj.Display();
	for (int i = 1; i <= row; i++)
	{
		if (Values[i][1] == "Intellivue" && ConvertToFloat(Values[i][3]) > 10)
		{
			cnt++;
			for (int j = 1; j <= col; j++)
			{
				cout << Values[i][j] << "		";
				if (Level == 1)
					Values1[cnt][j] = Values[i][j];
			}
			cout << endl;
		}
	}
	int cnt2 = cnt;
	if (Level == 1)
	{
		IntellivueBOPortability1(cnt, col, Values1, 2);
		IntellivueBOPortability2(cnt2, col, Values1, 2);
	}
	else if (!obj.Level2Test(Level, cnt))
	{
		return false;
	}	
	return true;
}
void FuncImplementation::IntellivueBOPortability(int row, int col, string Values[][20])
{
primary:
	cout << "Choose any one of these categories\nA.Portable\nB.Non-Portable\nC.Go Back " << endl;
	char choice;
	cin >> choice;
		UIFunction obj;
		BusinessLayer object;
	switch (choice)
	{
	case 'A':object.IntellivueBOPortability1(row, col, Values, 1);
		break;
	case 'B':object.IntellivueBOPortability2(row, col, Values, 1);
		break;
	case 'C':obj.Urban();
		break;
	default:
		obj.InvalidInput();		
		goto primary;		
	}	
}

bool BusinessLayer::IntellivueBOPortability1(int row, int col, string Values[][20], int Level)
{
	if (row == 0)return false;	
	cnt = 0;
	cout << endl << "Portable Monitors" << endl;
	UIFunction obj;
	obj.Display();
	for (int i = 1; i <= row; i++)
	{		
		if (Values[i][1] == "Intellivue" && Values[i][4] == "Yes")
		{
			cnt++;
			for (int j = 1; j <= col; j++)
			{
				cout << Values[i][j] << "		";
				if (Level == 1)Values1[cnt][j] = Values[i][j];
			}

			cout << endl;
		}
	}	
	int cnt2 = cnt;
	if (Level == 1)
	{
		IntellivueBOScreenSize1(cnt, col, Values1, 2);
		IntellivueBOScreenSize2(cnt2, col, Values1, 2);
	}
	else if (!obj.Level2Test(Level, cnt))
	{
		return false;
	}	
	return true;

}

bool BusinessLayer::IntellivueBOPortability2(int row, int col, string Values[][20], int Level)
{	
	if (row == 0)return false;	
	cnt = 0;
	cout << endl << "Non-Portable Monitors" << endl;
	UIFunction obj;
	obj.Display();
	for (int i = 1; i <= row; i++)
	{
		if (Values[i][1] == "Intellivue" && Values[i][4] == "No")
		{
			cnt++;
			for (int j = 1; j <= col; j++)
			{
				cout << Values[i][j] << "		";
				if (Level == 1)Values1[cnt][j] = Values[i][j];
			}

			cout << endl;
		}
	}
	int cnt2 = cnt;
	if (Level == 1)
	{
		IntellivueBOScreenSize1(cnt, col, Values1, 2);
		IntellivueBOScreenSize2(cnt2, col, Values1, 2);
	}	
	else if (!obj.Level2Test(Level, cnt))
	{
		return false;
	}	
	return true;
}


void FuncImplementation::EfficiaBOScreenSize(int row, int col, string Values[][20])
{
primary:
	cout << "Choose any one of these categories\nA.Small Screen\nB.Large Screen\nC.Go Back " << endl;
	char choice;
	cin >> choice;
	UIFunction obj;
	BusinessLayer object;
	switch (choice)
	{
	case 'A':object.EfficiaBOScreenSize1(row, col, Values, 1);
		break;
	case 'B':object.EfficiaBOScreenSize2(row, col, Values, 1);
		break;
	case 'C':obj.SemiUrban();
		break;
	default:
		obj.InvalidInput();		
		goto primary;		
	}
}

bool BusinessLayer::EfficiaBOScreenSize1(int row, int col, string Values[][20], int Level)
{	
	if (row == 0)return false;
	cout << endl << "Monitors with Screen Size < 12" << endl;
	cnt = 0;
	UIFunction obj;
	obj.Display();
	for (int i = 1; i <= row; i++)
	{
		if (Values[i][1] == "Efficia" && ConvertToFloat(Values[i][3]) < 12)
		{
			cnt++;
			for (int j = 1; j <= col; j++)
			{
				cout << Values[i][j] << "		";
				if (Level == 1)
					Values1[cnt][j] = Values[i][j];
			}
			cout << endl;
		}
	}
	int cnt2 = cnt;
	if (Level == 1)
	{
		EfficiaBOTouchScreen1(cnt, col, Values1, 2);
		EfficiaBOTouchScreen2(cnt2, col, Values1, 2);
	}
	else if (!obj.Level2Test(Level, cnt))
	{
		return false;
	}	
	return true;
}

bool BusinessLayer::EfficiaBOScreenSize2(int row, int col, string Values[][20], int Level)
{
	if (row == 0)return false;
	cout << endl << "Monitors with Screen Size > 12" << endl;
	cnt = 0;
	UIFunction obj;
	obj.Display();
	for (int i = 1; i <= row; i++)
	{
		if (Values[i][1] == "Efficia" && ConvertToFloat(Values[i][3]) >= 12)
		{
			cnt++;
			for (int j = 1; j <= col; j++)
			{
				cout << Values[i][j] << "		";
				if (Level == 1)
					Values1[cnt][j] = Values[i][j];
			}
			cout << endl;
		}
	}
	int cnt2 = cnt;
	if (Level == 1)
	{
		EfficiaBOTouchScreen1(cnt, col, Values1, 2);
		EfficiaBOTouchScreen2(cnt2, col, Values1, 2);
	}
	else if (!obj.Level2Test(Level, cnt))
	{
		return false;
	}	
	return true;
}

void FuncImplementation::EfficiaBOTouchScreen(int row, int col, string Values[][20])
{
primary:
	cout << "Choose any one of these categories\nA.Touch Screen\nB.No Touch Screen\nC.Go Back " << endl;
	char choice;
	cin >> choice;
	UIFunction obj;
	BusinessLayer object;
	switch (choice)
	{
	case 'A':object.EfficiaBOTouchScreen1(row, col, Values, 1);
		break;
	case 'B':object.EfficiaBOTouchScreen2(row, col, Values, 1);
		break;
	case 'C':obj.SemiUrban();
		break;
	default:
		obj.InvalidInput();		
		goto primary;		
	}
}

bool BusinessLayer::EfficiaBOTouchScreen1(int row, int col, string Values[][20], int Level)
{
	if (row == 0)return false;
	cout << endl << "Monitors that have a touch screen" << endl;
	cnt = 0;
	UIFunction obj;
	obj.Display();
	for (int i = 1; i <= row; i++)
	{
		if (Values[i][1] == "Efficia" && Values[i][5] == "Yes")
		{
			cnt++;
			for (int j = 1; j <= col; j++)
			{
				cout << Values[i][j] << "		";
				if (Level == 1)
					Values1[cnt][j] = Values[i][j];
			}
			cout << endl;
		}
	}
	int cnt2 = cnt;
	if (Level == 1)
	{
		EfficiaBOScreenSize1(cnt, col, Values1, 2);
		EfficiaBOScreenSize2(cnt2, col, Values1, 2);
	}
	else if (!obj.Level2Test(Level, cnt))
	{
		return false;
	}	
	return true;
}

bool BusinessLayer::EfficiaBOTouchScreen2(int row, int col, string Values[][20], int Level)
{
	if (row == 0)return false;
	cout << endl << "Monitors that don't have a touch screen" << endl;
	cnt = 0;
	UIFunction obj;
	obj.Display();
	for (int i = 1; i <= row; i++)
	{
		if (Values[i][1] == "Efficia" && Values[i][5] == "No")
		{
			cnt++;
			for (int j = 1; j <= col; j++)
			{
				cout << Values[i][j] << "		";
				if (Level == 1)
					Values1[cnt][j] = Values[i][j];
			}
			cout << endl;
		}
	}
	int cnt2 = cnt;
	if (Level == 1)
	{
		EfficiaBOScreenSize1(cnt, col, Values1, 2);
		EfficiaBOScreenSize2(cnt2, col, Values1, 2);
	}
	else if (!obj.Level2Test(Level, cnt))
	{
		return false;
	}	
	return true;
}



void FuncImplementation::AvalonBOCareStage(int row, int col, string Values[][20])
{
primary:
	cout << "Choose any one of these categories\nA.Intrapartum\nB.Antepartum\nC.Go Back " << endl;
	char choice;
	UIFunction obj;
	cin >> choice;
	BusinessLayer object;
	switch (choice)
	{
	case 'A':object.AvalonBOCareStage1(row, col, Values, 1);
		break;
	case 'B':object.AvalonBOCareStage2(row, col, Values, 1);
		break;
	case 'C':obj.labourcare();
		break;
	default:
		obj.InvalidInput();		
		goto primary;		
	}	
}

bool BusinessLayer::AvalonBOCareStage1(int row, int col, string Values[][20], int Level)
{
	if (row == 0)return false;
	cout << endl << "Monitors that are used during the Intrapartum care stage" << endl;
	cnt = 0;
	UIFunction obj;
	obj.Display();
	for (int i = 1; i <= row; i++)
	{
		if (Values[i][1] == "Avalon" && Values[i][8] == "Intrapartum")
		{
			cnt++;
			for (int j = 1; j <= col; j++)
			{
				cout << Values[i][j] << "		";
				if (Level == 1)
					Values1[cnt][j] = Values[i][j];
			}
			cout << endl;
		}
	}
	int cnt2 = cnt;
	if (Level == 1)
	{
		AvalonBOWeight1(cnt, col, Values1, 2);
		AvalonBOWeight2(cnt2, col, Values1, 2);
	}
	else if (!obj.Level2Test(Level, cnt))
	{
		return false;
	}	
	return true;
}

bool BusinessLayer::AvalonBOCareStage2(int row, int col, string Values[][20], int Level)
{
	if (row == 0)return false;
	cout << endl << "Monitors that are used during the Antepartum care stage" << endl;
	cnt = 0;
	UIFunction obj;
	obj.Display();
	for (int i = 1; i <= row; i++)
	{
		if (Values[i][1] == "Avalon" && Values[i][8] == "Antepartum")
		{
			cnt++;
			for (int j = 1; j <= col; j++)
			{
				cout << Values[i][j] << "		";
				if (Level == 1)
					Values1[cnt][j] = Values[i][j];
			}
			cout << endl;
		}
	}
	int cnt2 = cnt;
	if (Level == 1)
	{
		AvalonBOWeight1(cnt, col, Values1, 2);
		AvalonBOWeight2(cnt2, col, Values1, 2);
	}
	else if (!obj.Level2Test(Level, cnt))
	{
		return false;
	}
	return true;
}


void FuncImplementation::AvalonBOWeight(int row, int col, string Values[][20])
{
primary:
	cout << "Choose any one of these categories\nA.Light Weight Avalon Monitors\nB.Heavy Weight Avalon Monitors\nC.Go Back " << endl;
	char choice;
	cin >> choice;
	UIFunction obj;
	BusinessLayer object;
	switch (choice)
	{
	case 'A':object.AvalonBOWeight1(row, col, Values, 1);
		break;
	case 'B':object.AvalonBOWeight2(row, col, Values, 1);
		break;
	case 'C':obj.labourcare();
		break;
	default:
		obj.InvalidInput();		
		goto primary;		
	}

}


bool BusinessLayer::AvalonBOWeight1(int row, int col, string Values[][20], int Level)
{
	if (row == 0)return false;
	cout << endl << "Light Weight Avalon Monitors" << endl;
	cnt = 0;
	UIFunction obj;
	obj.Display();
	for (int i = 1; i <= row; i++)
	{
		if (Values[i][1] == "Avalon" && ConvertToFloat(Values[i][7])<6)
		{
			cnt++;
			for (int j = 1; j <= col; j++)
			{
				cout << Values[i][j] << "		";
				if (Level == 1)
					Values1[cnt][j] = Values[i][j];
			}
			cout << endl;
		}
	}
	int cnt2 = cnt;
	if (Level == 1)
	{
		AvalonBOCareStage1(cnt, col, Values1, 2);
		AvalonBOCareStage2(cnt2, col, Values1, 2);
	}
	else if (!obj.Level2Test(Level, cnt))
	{
		return false;
	}
	
	return true;
}

bool BusinessLayer::AvalonBOWeight2(int row, int col, string Values[][20], int Level)
{
	if (row == 0)return false;
	cout << endl << "Heavy Weight Avalon Monitors" << endl;
	cnt = 0;
	UIFunction obj;
	obj.Display();
	for (int i = 1; i <= row; i++)
	{
		if (Values[i][1] == "Avalon" && ConvertToFloat(Values[i][7])>8)
		{
			cnt++;
			for (int j = 1; j <= col; j++)
			{
				cout << Values[i][j] << "		";
				if (Level == 1)
					Values1[cnt][j] = Values[i][j];
			}
			cout << endl;
		}
	}
	int cnt2 = cnt;
	if (Level == 1)
	{
		AvalonBOCareStage1(cnt, col, Values1, 2);
		AvalonBOCareStage2(cnt2, col, Values1, 2);
	}
	else if (!obj.Level2Test(Level, cnt))
	{
		return false;
	}
	return true;
}



